import pandas as pd
import sys
feature_merge = pd.read_csv('feature_merge',sep='\t')
label_path = sys.argv[1]

label_file = pd.read_csv(label_path,sep='\t',names =['name','idcard','phone','loan_dt','label','source'])
combine_feature_label_data = pd.merge(feature_merge,label_file,on=['name','idcard','phone','loan_dt'],how = 'inner')
combine_feature_label_data_select_col = [x for x in combine_feature_label_data.columns if x not in ['update_dt','creditcard.report_time','name','idcard','phone','loan_dt','label','source']] + ['label','source','loan_dt']
print len(combine_feature_label_data_select_col)
combine_feature_label_data = combine_feature_label_data[combine_feature_label_data_select_col]

path_combine = label_path+'_feature'
combine_feature_label_data.to_csv(path_combine,'\t',index = False,header=True)
