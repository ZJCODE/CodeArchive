﻿Readme

###############################################################

将如下所列文件放到目录下：（将各个来源的特征merge，聚合平台merge不了的情况下用）

[ 使用 hadoop fs -getmerge [location] 获取聚合平台提取的特征到本地 ]

--------------------------
creditcard_result
danger_result （danger_result输出文件可能带有title 使用 sed -i '1d' danger_result 去除首行）
idmap_result
multiloan_result
qq_result
social_result
zhifubao_result
zhima_result
inop_result
multiloan_more（这个是多头新特征）
-------------------------

运行 python merge_feature.py 后会返回一个feature_merge的文件


###############################################################



随后运行 python add_label_to_feature.py sample_file_with_label  

[ sample_file_with_label 的文件安排如下:  'name','idcard','phone','loan_dt','label','source' ]

会返回文件 sample_file_with_label_feature  该文件前面几列特征，后三列  ['label','source','loan_dt']



