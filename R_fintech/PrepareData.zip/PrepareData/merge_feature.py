import pandas as pd

f = open('meta/credit.meta','r')
credit_head = f.readline().strip().split('\t')
f.close()
f = open('meta/danger.meta','r')
danger_head = f.readline().strip().split('\t')
f.close()
f = open('meta/idmap.meta','r')
idmap_head = f.readline().strip().split('\t')
f.close()
f = open('meta/multiloan.meta','r')
multiloan_head = f.readline().strip().split('\t')
f.close()
f = open('meta/qq.meta','r')
qq_head = f.readline().strip().split('\t')
f.close()
f = open('meta/social.meta','r')
social_head = f.readline().strip().split('\t')
f.close()
f = open('meta/zfb.meta','r')
zhifubao_head = f.readline().strip().split('\t')
f.close()
f = open('meta/zhima.meta','r')
zhima_head = f.readline().strip().split('\t')
f.close()
f = open('meta/inop.meta','r')
inop_head = f.readline().strip().split('\t')
f.close()
f = open('meta/multi_loan_2_1_1.meta','r')
multi_more_head = f.readline().strip().split('\t')
f.close()

print 'creditcard_result'
creditcard_result = pd.read_csv('creditcard_result',names = credit_head,sep='\t')
print creditcard_result.shape
print 'danger_result'
danger_result = pd.read_csv('danger_result',names = danger_head,sep='\t')
print danger_result.shape
print 'idmap_result'
idmap_result = pd.read_csv('idmap_result',names = idmap_head,sep='\t')
print idmap_result.shape
print 'multiloan_result'
multiloan_result = pd.read_csv('multiloan_result',names = multiloan_head,sep='\t')
multiloan_result['name'] = ['name']*len(multiloan_result)
print multiloan_result.shape
print 'qq_result'
qq_result = pd.read_csv('qq_result',names = qq_head,sep='\t')
print qq_result.shape
print 'social_result'
social_result = pd.read_csv('social_result',names = social_head,sep='\t')
print social_result.shape
print 'zhifubao_result'
zhifubao_result = pd.read_csv('zhifubao_result',names = zhifubao_head,sep='\t')
print zhifubao_result.shape
print 'zhima_result'
zhima_result = pd.read_csv('zhima_result',names = zhima_head,sep='\t')
print zhima_result.shape
#del zhima_result['update_dt']
print 'inop_result'
inop_result = pd.read_csv('inop_result',names = inop_head,sep='\t')
print inop_result.shape
print 'multiloan_more'
multiloan_more = pd.read_csv('multiloan_more',names=multi_more_head,sep='\t')
print multiloan_more.shape


print 'merge creditcard_result , danger_result'
feature_merge = pd.merge(creditcard_result,danger_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge idmap_result'
feature_merge = pd.merge(feature_merge,idmap_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge multiloan_result'
feature_merge = pd.merge(feature_merge,multiloan_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge qq_result'
feature_merge = pd.merge(feature_merge,qq_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge zhifubao_result'
feature_merge = pd.merge(feature_merge,zhifubao_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge zhima_result'
feature_merge = pd.merge(feature_merge,zhima_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge social_result'
feature_merge = pd.merge(feature_merge,social_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge inop_result'
feature_merge = pd.merge(feature_merge,inop_result,on=['name','idcard','phone','loan_dt'],how='outer')
print 'merge multiloan_more'
feature_merge = pd.merge(feature_merge,multiloan_more,on=['name','idcard','phone','loan_dt'],how='outer')

feature_merge = feature_merge.drop_duplicates()

feature_merge.to_csv('feature_merge',sep='\t',index=False)
