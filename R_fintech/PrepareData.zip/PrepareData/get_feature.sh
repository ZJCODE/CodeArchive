python merge_feature.py

python add_label_to_feature.py sample_file_with_label  # 'name','idcard','phone','loan_dt','label','source'

